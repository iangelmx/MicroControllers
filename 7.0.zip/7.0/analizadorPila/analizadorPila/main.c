/*
 * analizadorPila.c
 *
 * Created: 28/03/2017 07:20:25 p. m.
 * Author : Teodoro
 */ 

#include <avr/io.h>
#include <avr/interrupt.h>

#define  F_CPU 1000000UL
#include <util/delay.h>


unsigned char dato;

ISR(ADC_vect)
{
	dato = ADCH;
}

int main(void)
{
	DDRB = 0x01;
	ADMUX = 0xE0;
	DIDR0 = 0x01;
	ADCSRA = 0xEB;

	PORTB  &= 0xFE;

    /* Replace with your application code */
    while (1) 
    {
		if(dato < 164)
		{
			PORTB |= 0x01;
			_delay_ms(100);
			PORTB &= 0xFE;
			_delay_ms(100);
			PORTB |= 0x01;
			_delay_ms(100);
			PORTB &= 0xFE;
			_delay_ms(100);
		}
    }
}

