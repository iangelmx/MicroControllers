/*
 * mi_pwm_c.c
 *
 * Created: 22/02/2017 07:32:47 p. m.
 * Author : Teodoro
 */ 

#include <avr/io.h>
#define F_CPU 1000000UL
#include <util/delay.h>

int main(void)
{
	DDRC = 0x00;
	PORTC = 0x03;
	TCCR0A = 0x81;
	TCCR0B = 0x01;
	OCR0A = 130;
	DDRD |= 1<<6;


    /* Replace with your application code */
    while (1) 
    {
		if (!(PINC&0x01))
		{
			//_delay_ms(50);
			OCR0A = OCR0A + 5;
		}else if (!(PINC&0x02))
		{
			//_delay_ms(50);
			OCR0A = OCR0A - 5;
		}
    }
}

